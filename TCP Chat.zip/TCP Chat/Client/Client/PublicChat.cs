﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class PublicChat : Form
    {
        public PublicChat()
        {
            pchat=new PrivateChat(this);
            InitializeComponent();
        }

        private void TxtReceive_TextChanged(object sender, EventArgs e)
        {
            txtReceive.SelectionStart = txtReceive.TextLength;
        }

        public readonly Main formLogin=new Main();

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            formLogin.Client.Received += _client_Received;
            formLogin.Client.Disconnected += Client_Disconnected;
            Text = "TCP Chat " + formLogin.textBox1.Text + " (Connected as:" + formLogin.txtUsername.Text+")";
            formLogin.ShowDialog();
        }

        private static void Client_Disconnected(ClientSettings cs)
        {

        }

        private void BtnSend_Click(object sender, EventArgs e)
        {
            if (txtInput.Text != string.Empty)
            {
                formLogin.Client.Send("Message|"+formLogin.txtUsername.Text+"|"+txtInput.Text);
                txtReceive.Text += formLogin.txtUsername.Text + " says: " + txtInput.Text + "\r\n";
                txtInput.Text = string.Empty;
            }
        }

        private readonly PrivateChat pchat;

        public void _client_Received(ClientSettings cs, string received)
        {
            var cmd = received.Split('|');
            switch (cmd[0])
            {
                case "Users":
                    this.Invoke(() =>
                    {
                        userList.Items.Clear();
                        for (int i = 1; i < cmd.Length; i++)
                        {
                            if ((cmd[i]!= "Connected") /*|| (cmd[i]! = "RefreshChat")*/)
                            {
                                userList.Items.Add(cmd[i]);
                            }
                        }
                    });
                    break;
                case "Message":
                    this.Invoke(() =>
                    {
                        txtReceive.Text += cmd[1] + "\r\n";
                    });
                    break;
                case "RefreshChat":
                    this.Invoke(() =>
                    {
                        txtReceive.Text = cmd[1];
                    });
                    break;
                case "Chat":
                    this.Invoke(() =>
                    {
                        pchat.Text = pchat.Text.Replace("user", formLogin.txtUsername.Text);
                        pchat.Show();
                    });
                    break;
                case "pMessage":
                    this.Invoke(() =>
                    {
                        pchat.txtReceive.Text += "Server says: " + cmd[1] + "\r\n";
                    });
                    break;
                case "Disconnect":
                    Application.Exit();
                    break;
            }
        }

        private void TxtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSend.PerformClick();
            }
        }

        private void TxtInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void privateChat_Click(object sender, EventArgs e)
        {
            formLogin.Client.Send("pChat|"+formLogin.txtUsername.Text);
        }
    }
}
