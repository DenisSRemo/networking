﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class PrivateChat : Form
    {

        private readonly Main Main;
        public PrivateChat(Main main)
        {
            InitializeComponent();
            Main = main;
        }


        

        private void TxtInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void PrivateChat_Load(object sender, EventArgs e)
        {

        }

        public void TxtReceive_TextChanged_1(object sender, EventArgs e)
        {
            txtReceive.SelectionStart = txtReceive.TextLength;
        }

        private void TxtInput_KeyDown_1(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
                btnSend.PerformClick();
        }

        private void BtnSend_Click_1(object sender, EventArgs e)
        {

            if (txtInput.Text != string.Empty)
            {
                foreach (var client in from ListViewItem item in Main.clientList.SelectedItems select (Client)item.Tag)
                {
                    client.Send("pMessage|" + txtInput.Text + "\r\n");

                }

                txtReceive.Text += "Server says: " + txtInput.Text + "\r\n";
                txtInput.Text = string.Empty;
            }
        }
    }
}
